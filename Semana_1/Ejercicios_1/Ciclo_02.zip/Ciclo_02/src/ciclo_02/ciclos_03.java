
package ciclo_02;
public class ciclos_03 {
    
    public static void main(String[] arg){
    
    
        for(int i=0;i<10;i++){

        }
        
    }
    
    
}
