package ciclo_02;

import java.util.Scanner;

public class leerdatos_08 {
    
    public static void main(String[] arg){
        //declaracion = iniciacion 
        Scanner leer  = new Scanner(System.in);
        System.out.println("Ingrese mensaje");
        String msg=leer.nextLine();
        System.out.println("Mensaje: "+msg);
    
    }
    
}
