
package ciclo_02;

import javax.swing.JOptionPane;

public class leerdatos_joption_09 {
    
    public static void main(String[] arg){
    
        String mensaje=(JOptionPane.showInputDialog("Ingrese un" +
        " mensaje"));       
        System.out.println("Mensaje:" +mensaje);

        JOptionPane.showMessageDialog(null,mensaje);    
          
          
          
          

    
    }
    
}
